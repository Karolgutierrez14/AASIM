import numpy as np
import pandas as pd

from proyecto_asim.image_preprocessing import (
    normalize_image,
    resize_with_padding,
)


def test_normalization_range():
    image = np.array(
        [
            [
                [0, 128, 255],
                [255, 0, 64],
            ]
        ],
        dtype=np.uint8,
    )

    result = normalize_image(
        image
    )

    assert result.dtype == np.float32
    assert result.min() >= 0.0
    assert result.max() <= 1.0


def test_resize_shape():
    image = np.zeros(
        (
            300,
            500,
            3,
        ),
        dtype=np.uint8,
    )

    result = resize_with_padding(
        image
    )

    assert result.shape == (
        224,
        224,
        3,
    )


def test_split_ids_are_unique():
    train = pd.DataFrame(
        {
            "sample_id": [
                "train:A",
                "train:B",
            ]
        }
    )

    validation = pd.DataFrame(
        {
            "sample_id": [
                "train:C",
            ]
        }
    )

    assert set(
        train["sample_id"]
    ).isdisjoint(
        set(
            validation[
                "sample_id"
            ]
        )
    )

def test_stratified_split_is_70_30():
    from proyecto_asim.prepare_dataset import create_train_test_split

    df = pd.DataFrame({
        "Image name": [f"img_{i}" for i in range(100)],
        "Retinopathy grade": [grade for grade in range(5) for _ in range(20)],
        "sample_id": [f"train:img_{i}" for i in range(100)],
        "image_path": [f"data/img_{i}.jpg" for i in range(100)],
    })
    train, heldout = create_train_test_split(df)
    assert len(train) == 70
    assert len(heldout) == 30
    assert set(train["sample_id"]).isdisjoint(set(heldout["sample_id"]))
    assert train["Retinopathy grade"].value_counts().to_dict() == {0: 14, 1: 14, 2: 14, 3: 14, 4: 14}
    assert heldout["Retinopathy grade"].value_counts().to_dict() == {0: 6, 1: 6, 2: 6, 3: 6, 4: 6}


def test_histograms_reject_non_train_rows():
    import pytest

    from proyecto_asim.pixel_classification import generate_pixel_intensity_reports

    df = pd.DataFrame({
        "image_path": ["missing.jpg"],
        "Retinopathy grade": [0],
        "model_split": ["validation"],
    })
    with pytest.raises(ValueError, match="solo pueden calcularse"):
        generate_pixel_intensity_reports(df)
