def main() -> None:
    print("Hello from proyecto-asim!")
