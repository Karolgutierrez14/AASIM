"""Histogramas RGB calculados exclusivamente con el split train de Fase 3."""
from pathlib import Path

import cv2
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

RESULTS_DIR = Path("results", "phase3", "histograms")
FIGURES_DIR = Path("figures", "phase3", "histograms")


def calcular_histogramas_por_imagen(subset_df: pd.DataFrame):
    """Calcula histogramas RGB normalizados a partir de image_path.

    No busca imágenes en carpetas por nombre: usa las rutas exactas del
    manifiesto ya particionado. Así se evita mezclar train con validation/test.
    Retorna (B, G, R), matrices con una fila por imagen válida.
    """
    histograms = {"B": [], "G": [], "R": []}
    for _, row in subset_df.iterrows():
        image_path = Path(str(row["image_path"]))
        image = cv2.imread(str(image_path))
        if image is None:
            raise ValueError(f"No se pudo leer la imagen de train: {image_path}")
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(gray, 10, 255, cv2.THRESH_BINARY)
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
        for channel, key in ((0, "B"), (1, "G"), (2, "R")):
            hist = cv2.calcHist([image], [channel], mask, [256], [0, 256]).ravel()
            total = float(hist.sum())
            if total > 0:
                histograms[key].append(hist / total)
    arrays = {key: np.asarray(value, dtype=np.float64) for key, value in histograms.items()}
    return arrays["B"], arrays["G"], arrays["R"]


def guardar_grafica_max_min(hist_max, hist_min, area, titulo, color_base, output_path):
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    bins = np.arange(256)
    plt.figure(figsize=(9, 5))
    plt.plot(bins, hist_max, color=color_base, linewidth=1.8, label="Percentil 95")
    plt.plot(bins, hist_min, color="black", linewidth=1.5, linestyle="--", label="Percentil 5")
    plt.fill_between(bins, hist_min, hist_max, color=color_base, alpha=0.2, label=f"Área entre curvas: {area:.4f}")
    plt.title(titulo)
    plt.xlabel("Intensidad de píxel (0–255)")
    plt.ylabel("Densidad normalizada")
    plt.legend(loc="upper right")
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()


def generate_pixel_intensity_reports(df_train: pd.DataFrame):
    """Genera histogramas/envolventes RGB usando SOLO train ya particionado.

    Requiere las columnas `image_path`, `Retinopathy grade` y `model_split`.
    Guarda CSV de resumen y figuras. Falla explícitamente si recibe filas que
    no pertenezcan a train, para prevenir fugas accidentales.
    """
    required = {"image_path", "Retinopathy grade", "model_split"}
    missing = required - set(df_train.columns)
    if missing:
        raise ValueError(f"Faltan columnas para histogramas: {sorted(missing)}")
    if not df_train["model_split"].eq("train").all():
        raise ValueError("Los histogramas solo pueden calcularse con model_split='train'.")
    if df_train.empty:
        raise ValueError("El split train está vacío; no se pueden generar histogramas.")

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    grouped = df_train.copy()
    grouped["Severity_Group"] = grouped["Retinopathy grade"].replace({1: "1_2", 2: "1_2"}).astype(str)
    rows = []
    channel_map = {"Blue": ("blue", 0), "Green": ("green", 1), "Red": ("red", 2)}
    for group, subset in grouped.groupby("Severity_Group", sort=True):
        hb, hg, hr = calcular_histogramas_por_imagen(subset)
        channel_data = {"Blue": hb, "Green": hg, "Red": hr}
        for channel_name, (color, _) in channel_map.items():
            hists = channel_data[channel_name]
            if hists.size == 0:
                rows.append({"severity_group": str(group), "channel": channel_name, "n_images": len(subset), "status": "sin_pixeles_validos", "area_p05_p95": None})
                continue
            hist_max = np.percentile(hists, 95, axis=0)
            hist_min = np.percentile(hists, 5, axis=0)
            area = float(np.sum(np.abs(hist_max - hist_min)))
            output_path = FIGURES_DIR / f"severity_group_{group}_{channel_name.lower()}.png"
            guardar_grafica_max_min(hist_max, hist_min, area, f"Train Fase 3 — grupo {group}, canal {channel_name}", color, output_path)
            rows.append({"severity_group": str(group), "channel": channel_name, "n_images": len(hists), "status": "ok", "area_p05_p95": area, "figure": output_path.as_posix()})
    result = pd.DataFrame(rows)
    result.to_csv(RESULTS_DIR / "histogram_summary.csv", index=False)
    metadata = {"source_split": "train", "source_manifest": "data/processed/<dataset_version>/train.csv", "n_train_images": len(df_train), "class_counts": {str(k): int(v) for k, v in df_train["Retinopathy grade"].value_counts().sort_index().items()}, "histogram_bins": 256, "mask": "umbral de gris > 10 y apertura morfológica 5x5", "envelope": "percentiles 5 y 95 entre histogramas normalizados por imagen", "summary_csv": (RESULTS_DIR / "histogram_summary.csv").as_posix()}
    import json
    (RESULTS_DIR / "histogram_metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Histogramas calculados exclusivamente con {len(df_train)} imágenes del split train.")
    print(f"Resumen: {RESULTS_DIR / 'histogram_summary.csv'}")
    return result
