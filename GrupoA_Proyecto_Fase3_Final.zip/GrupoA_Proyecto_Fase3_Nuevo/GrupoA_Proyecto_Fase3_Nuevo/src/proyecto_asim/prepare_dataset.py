import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

# ============================================================
# CONFIGURACIÓN
# ============================================================

DATASET_VERSION = "abt_v20261012"

TEST_HOLDOUT_SIZE = 0.30
RANDOM_STATE = 42

RAW_DIR = Path(
    "data",
    "raw",
    "Disease_Grading",
)

IMAGES_DIR = (
    RAW_DIR
    / "Original_Images"
)

TRAIN_IMAGES_DIR = (
    IMAGES_DIR
    / "Training Set"
)

TEST_IMAGES_DIR = (
    IMAGES_DIR
    / "Testing Set"
)

PROCESSED_DIR = (
    Path("data")
    / "processed"
    / DATASET_VERSION
)

RESULTS_DIR = (
    Path("results")
    / "phase3"
)


# ============================================================
# BUSCAR IMAGEN
# ============================================================

def find_image_path(
    image_name,
    source_split,
):
    """
    Busca una imagen de IDRiD dentro de la carpeta
    correspondiente al conjunto oficial.
    """

    if source_split == "TRAIN":
        image_dir = TRAIN_IMAGES_DIR

    elif source_split == "TEST":
        image_dir = TEST_IMAGES_DIR

    else:
        raise ValueError(
            f"source_split no válido: {source_split}"
        )

    extensions = [
        ".jpg",
        ".jpeg",
        ".png",
        ".JPG",
        ".JPEG",
        ".PNG",
    ]

    for extension in extensions:

        candidate = (
            image_dir
            / f"{image_name}{extension}"
        )

        if candidate.exists():
            return candidate

    raise FileNotFoundError(
        "No se encontró la imagen "
        f"{image_name} en {image_dir}"
    )


# ============================================================
# AÑADIR RUTAS
# ============================================================

def add_image_paths(
    df,
    source_split,
):
    """
    Añade:

    - source_split
    - sample_id
    - image_path

    al DataFrame original.
    """

    df = df.copy()

    df["source_split"] = (
        source_split
    )

    df["sample_id"] = (
        source_split.lower()
        + ":"
        + df[
            "Image name"
        ].astype(str)
    )

    image_paths = []

    for image_name in df[
        "Image name"
    ]:

        image_path = (
            find_image_path(
                image_name,
                source_split,
            )
        )

        image_paths.append(
            image_path.as_posix()
        )

    df["image_path"] = (
        image_paths
    )

    return df


# ============================================================
# DIVIDIR TRAIN Y VALIDATION
# ============================================================

def create_train_test_split(df_train):
    """Divide el Training Set oficial en 70 % train y 30 % test interno.

    La división es estratificada por Retinopathy grade. El 30 % se combina
    después con el Testing Set oficial para crear el conjunto final de prueba.
    """
    train_df, heldout_df = train_test_split(
        df_train,
        test_size=TEST_HOLDOUT_SIZE,
        random_state=RANDOM_STATE,
        stratify=df_train["Retinopathy grade"],
    )
    train_df = train_df.copy().reset_index(drop=True)
    heldout_df = heldout_df.copy().reset_index(drop=True)
    train_df["model_split"] = "train"
    heldout_df["model_split"] = "test"
    heldout_df["test_origin"] = "heldout_from_training"
    return train_df, heldout_df


# ============================================================
# CREAR DATASET MODELABLE
# ============================================================

def create_modelable_dataset(df_train, df_test):
    """Crea train=70 % del Training Set y test=30 % retenido + Testing oficial.

    Las imágenes originales nunca se mueven ni se sobrescriben. El 30 % se
    estratifica por grado (0,1,2,3,4) y se concatena al Testing Set oficial.
    No se crea validation: el conjunto combinado se reserva para evaluación.
    """
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    train_source = add_image_paths(df_train, "TRAIN")
    official_test = add_image_paths(df_test, "TEST")
    train_model, heldout_model = create_train_test_split(train_source)

    official_test = official_test.copy().reset_index(drop=True)
    official_test["model_split"] = "test"
    official_test["test_origin"] = "official_testing_set"

    # El testing final contiene tanto las imágenes oficiales como el 30 % retenido.
    test_model = pd.concat([heldout_model, official_test], ignore_index=True)
    test_model = test_model.drop_duplicates(subset=["sample_id"], keep="first")

    columns = ["sample_id", "Image name", "image_path", "Retinopathy grade",
               "Risk of macular edema", "source_split", "model_split", "test_origin"]
    train_model["test_origin"] = "not_applicable"
    train_model = train_model[columns].sort_values("sample_id").reset_index(drop=True)
    test_model = test_model[columns].sort_values("sample_id").reset_index(drop=True)

    # Se conserva validation.csv vacío por compatibilidad con herramientas antiguas;
    # el flujo oficial no usa validation como conjunto de evaluación.
    validation_model = pd.DataFrame(columns=columns)

    train_model.to_csv(PROCESSED_DIR / "train.csv", index=False)
    validation_model.to_csv(PROCESSED_DIR / "validation.csv", index=False)
    test_model.to_csv(PROCESSED_DIR / "test.csv", index=False)
    test_model[test_model["test_origin"] == "heldout_from_training"].to_csv(
        PROCESSED_DIR / "heldout_from_training.csv", index=False)
    test_model[test_model["test_origin"] == "official_testing_set"].to_csv(
        PROCESSED_DIR / "official_test.csv", index=False)
    manifest = pd.concat([train_model, test_model], ignore_index=True)
    manifest.to_csv(PROCESSED_DIR / "manifest.csv", index=False)

    def counts_by_grade(frame):
        counts = frame["Retinopathy grade"].value_counts().sort_index()
        return {str(int(k)): int(v) for k, v in counts.items()}

    metadata = {
        "dataset": "IDRiD", "subset": "Disease_Grading",
        "dataset_version": DATASET_VERSION,
        "target": "Retinopathy grade", "target_domain": [0, 1, 2, 3, 4],
        "train_fraction_from_official_training": 0.70,
        "heldout_fraction_from_official_training": 0.30,
        "random_state": RANDOM_STATE,
        "stratification_column": "Retinopathy grade",
        "counts": {"train": len(train_model), "heldout_from_training": len(heldout_model),
                   "official_test": len(official_test), "test_combined": len(test_model),
                   "total_unique_samples": len(manifest)},
        "class_counts": {"train": counts_by_grade(train_model),
                          "heldout_from_training": counts_by_grade(heldout_model),
                          "official_test": counts_by_grade(official_test),
                          "test_combined": counts_by_grade(test_model)},
        "split_strategy": "El Training Set oficial se divide estratificadamente 70/30. El 70 % queda en train. El 30 % retenido se combina con todas las imágenes del Testing Set oficial en test.csv. No se usa validation independiente.",
        "warning": "El test combinado incluye imágenes retenidas del Training Set y el Testing Set oficial; reportar por separado resultados sobre official_test si se requiere comparación oficial.",
    }
    (PROCESSED_DIR / "dataset_metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")

    print("\nDataset modelable generado:", DATASET_VERSION)
    print("Train 70 %:", len(train_model))
    print("30 % retenido + test oficial:", len(test_model),
          f"({len(heldout_model)} retenidas + {len(official_test)} oficiales)")
    print("Distribución train:", metadata["class_counts"]["train"])
    print("Distribución test combinado:", metadata["class_counts"]["test_combined"])
    return train_model, validation_model, test_model

