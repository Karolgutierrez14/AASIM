import hashlib
import json
from pathlib import Path

import pandas as pd

RESULTS_DIR = Path("results", "phase3")

EXPECTED_CLASSES = {
    0,
    1,
    2,
    3,
    4,
}


# HASH SHA-256
def calculate_sha256(file_path):
    """
    Calcula el hash SHA-256 de un archivo.

    El hash permite identificar archivos binariamente idénticos.

    Si dos imágenes de particiones diferentes tienen el mismo
    SHA-256, existe evidencia de que el mismo contenido está
    presente en más de una partición.

    Parameters
    ----------
    file_path : str | Path
        Ruta del archivo de imagen.

    Returns
    -------
    str
        Hash SHA-256 del archivo.
    """

    file_path = Path(
        file_path
    )

    if not file_path.exists():
        raise FileNotFoundError(
            f"No existe el archivo: {file_path}"
        )

    sha256 = hashlib.sha256()

    with open(
        file_path,
        "rb",
    ) as file:

        while True:

            block = file.read(
                1024 * 1024
            )

            if not block:
                break

            sha256.update(
                block
            )

    return sha256.hexdigest()


# ============================================================
# VALIDAR RUTAS DE IMÁGENES
# ============================================================

def validate_image_paths(
    train_df,
    validation_df,
    test_df,
):
    """
    Verifica que todas las rutas declaradas en image_path
    existan realmente.

    Se realiza la comprobación por separado para:

    - train
    - validation
    - test

    Returns
    -------
    dict
        Resumen de rutas existentes y faltantes.
    """

    datasets = {
        "train": train_df,
        "validation": validation_df,
        "test": test_df,
    }

    result = {}

    for split_name, df in datasets.items():

        missing_paths = []

        existing_paths = 0

        for image_path in df[
            "image_path"
        ]:

            path = Path(
                image_path
            )

            if path.exists():
                existing_paths += 1

            else:
                missing_paths.append(
                    str(path)
                )

        result[
            split_name
        ] = {
            "total_records": len(
                df
            ),
            "existing_images": (
                existing_paths
            ),
            "missing_images": len(
                missing_paths
            ),
            "all_images_exist": (
                len(
                    missing_paths
                )
                == 0
            ),
            "missing_paths": (
                missing_paths
            ),
        }

    return result


# ============================================================
# VALIDAR CLASES
# ============================================================

def validate_all_classes(
    df,
    split_name,
):
    """
    Verifica si una partición contiene las cinco clases
    esperadas de Retinopathy grade.

    Clases esperadas:

        0
        1
        2
        3
        4

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame de la partición.

    split_name : str
        Nombre de la partición.

    Returns
    -------
    dict
        Resultado de la validación.
    """

    observed = {
        int(value)
        for value
        in df["Retinopathy grade"].dropna().unique()
    }

    missing = (EXPECTED_CLASSES - observed)

    unexpected = (observed - EXPECTED_CLASSES)

    return {
        "split": split_name,
        "expected_classes": sorted(
            EXPECTED_CLASSES
        ),
        "observed_classes": sorted(
            observed
        ),
        "missing_classes": sorted(
            missing
        ),
        "unexpected_classes": sorted(
            unexpected
        ),
        "all_expected_classes_present": (
            len(
                missing
            )
            == 0
        ),
        "only_expected_classes_present": (
            len(
                unexpected
            )
            == 0
        ),
    }


# DISTRIBUCIÓN DE CLASES
def create_split_class_distribution(
    train_df,
    validation_df,
    test_df,
):
    """Genera la distribución de Retinopathy grade
    para train, validation y test.

    Guarda:
        results/phase3/class_distribution.csv

    El archivo contiene:
    - Split
    - Retinopathy grade
    - Cantidad
    - Porcentaje (%)

    Returns
    -------
    pandas.DataFrame
        Tabla de distribución.
    """

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    datasets = {
        "train": train_df,
        "validation": validation_df,
        "test": test_df,
    }

    rows = []

    for split_name, df in datasets.items():

        counts = (
            df[
                "Retinopathy grade"
            ]
            .value_counts()
            .sort_index()
        )

        percentages = (
            df["Retinopathy grade"].value_counts(normalize=True).sort_index() * 100
        )

        for grade in range(5):

            count = int(counts.get(grade, 0))

            percentage = float(
                percentages.get(
                    grade,
                    0.0,
                )
            )

            rows.append(
                {
                    "Split": (
                        split_name
                    ),
                    "Retinopathy grade": (
                        grade
                    ),
                    "Cantidad": (
                        count
                    ),
                    "Porcentaje (%)": (
                        round(
                            percentage,
                            2,
                        )
                    ),
                }
            )

    distribution = pd.DataFrame(rows)

    output_path = (
        RESULTS_DIR
        / "class_distribution.csv"
    )

    distribution.to_csv(
        output_path,
        index=False,
    )

    print("\nDistribución de clases guardada en:")
    print(output_path)

    return distribution


# VALIDAR DUPLICADOS DENTRO DE CADA SPLIT
def validate_internal_duplicates(
    train_df,
    validation_df,
    test_df,
):
    """
    Verifica duplicados de sample_id dentro de cada partición.

    Returns
    -------
    dict
        Cantidad y listado de IDs duplicados por partición.
    """

    datasets = {
        "train": train_df,
        "validation": validation_df,
        "test": test_df,
    }

    result = {}

    for split_name, df in datasets.items():

        duplicated_mask = (
            df[
                "sample_id"
            ].duplicated(
                keep=False
            )
        )

        duplicated_ids = sorted(
            df.loc[
                duplicated_mask,
                "sample_id",
            ]
            .astype(str)
            .unique()
            .tolist()
        )

        result[
            split_name
        ] = {
            "number_of_duplicate_ids": (
                len(
                    duplicated_ids
                )
            ),
            "duplicate_ids": (
                duplicated_ids
            ),
            "valid": (
                len(
                    duplicated_ids
                )
                == 0
            ),
        }

    return result


# VALIDAR SOLAPAMIENTO DE sample_id
def validate_sample_ids(
    train_df,
    validation_df,
    test_df,
):
    """
    Verifica que sample_id no se repita entre particiones.

    IMPORTANTE
    ----------
    sample_id debe ser un identificador compuesto, por ejemplo:

        train:IDRiD_001
        test:IDRiD_001

    Esto evita considerar automáticamente como fuga dos
    identificadores con el mismo nombre pero provenientes
    de carpetas oficiales distintas.

    Returns
    -------
    dict
        Solapamientos encontrados.
    """

    train_ids = set(
        train_df[
            "sample_id"
        ].astype(str)
    )

    validation_ids = set(
        validation_df[
            "sample_id"
        ].astype(str)
    )

    test_ids = set(
        test_df[
            "sample_id"
        ].astype(str)
    )

    train_validation = sorted(
        train_ids
        & validation_ids
    )

    train_test = sorted(
        train_ids
        & test_ids
    )

    validation_test = sorted(
        validation_ids
        & test_ids
    )

    return {
        "train_validation_overlap": (
            train_validation
        ),
        "train_test_overlap": (
            train_test
        ),
        "validation_test_overlap": (
            validation_test
        ),
        "no_sample_id_leakage": (
            len(
                train_validation
            )
            == 0
            and len(
                train_test
            )
            == 0
            and len(
                validation_test
            )
            == 0
        ),
    }


# ============================================================
# AÑADIR HASHES
# ============================================================

def add_file_hashes(
    df,
):
    """
    Calcula el SHA-256 de cada imagen declarada en image_path.

    Se devuelve una copia del DataFrame con una nueva columna:

        sha256

    Returns
    -------
    pandas.DataFrame
    """

    df = df.copy()

    hashes = []

    for image_path in df[
        "image_path"
    ]:

        image_hash = (
            calculate_sha256(
                image_path
            )
        )

        hashes.append(
            image_hash
        )

    df[
        "sha256"
    ] = hashes

    return df


# ============================================================
# VALIDAR DUPLICADOS EXACTOS POR HASH
# ============================================================

def validate_hash_overlap(
    train_df,
    validation_df,
    test_df,
):
    """
    Busca imágenes binariamente idénticas entre particiones.

    La comparación utiliza SHA-256.

    Esta validación es más fuerte que comparar únicamente
    nombres de archivo.

    Returns
    -------
    dict
    """

    train_hashes = set(
        train_df[
            "sha256"
        ]
    )

    validation_hashes = set(
        validation_df[
            "sha256"
        ]
    )

    test_hashes = set(
        test_df[
            "sha256"
        ]
    )

    train_validation = sorted(
        train_hashes
        & validation_hashes
    )

    train_test = sorted(
        train_hashes
        & test_hashes
    )

    validation_test = sorted(
        validation_hashes
        & test_hashes
    )

    return {
        "train_validation_duplicate_hashes": (
            train_validation
        ),
        "train_test_duplicate_hashes": (
            train_test
        ),
        "validation_test_duplicate_hashes": (
            validation_test
        ),
        "no_exact_image_leakage": (
            len(
                train_validation
            )
            == 0
            and len(
                train_test
            )
            == 0
            and len(
                validation_test
            )
            == 0
        ),
    }


# ============================================================
# VALIDAR LABELS
# ============================================================

def validate_target_domain(
    train_df,
    validation_df,
    test_df,
):
    """
    Verifica que Retinopathy grade solo contenga
    valores del dominio esperado 0-4.
    """

    datasets = {
        "train": train_df,
        "validation": validation_df,
        "test": test_df,
    }

    result = {}

    for split_name, df in datasets.items():

        observed = {
            int(value)
            for value
            in df["Retinopathy grade"].dropna().unique()
        }

        invalid = sorted(observed - EXPECTED_CLASSES)

        result[
            split_name
        ] = {
            "invalid_classes": (
                invalid
            ),
            "number_of_invalid_classes": (
                len(
                    invalid
                )
            ),
            "valid": (
                len(
                    invalid
                )
                == 0
            ),
        }

    return result


# VALIDAR VALORES FALTANTES IMPORTANTES
def validate_required_fields(
    train_df,
    validation_df,
    test_df,
):
    """
    Verifica valores faltantes en los campos necesarios
    para modelado.

    Campos revisados:

    - sample_id
    - Image name
    - image_path
    - Retinopathy grade
    - model_split
    """

    required_columns = [
        "sample_id",
        "Image name",
        "image_path",
        "Retinopathy grade",
        "model_split",
    ]

    datasets = {
        "train": train_df,
        "validation": validation_df,
        "test": test_df,
    }

    result = {}

    for split_name, df in datasets.items():

        missing_columns = [
            column
            for column
            in required_columns
            if column
            not in df.columns
        ]

        missing_values = {}

        for column in required_columns:

            if column in df.columns:

                missing_values[
                    column
                ] = int(
                    df[
                        column
                    ].isna().sum()
                )

        result[
            split_name
        ] = {
            "missing_columns": (
                missing_columns
            ),
            "missing_values": (
                missing_values
            ),
            "valid": (
                len(
                    missing_columns
                )
                == 0
                and all(
                    value == 0
                    for value
                    in missing_values.values()
                )
            ),
        }

    return result


# ============================================================
# VALIDAR NOMBRE DE SPLIT
# ============================================================

def validate_model_split_column(
    train_df,
    validation_df,
    test_df,
):
    """
    Verifica que cada DataFrame tenga el valor correcto
    en la columna model_split.
    """

    expected = {
        "train": (
            train_df,
            "train",
        ),
        "validation": (
            validation_df,
            "validation",
        ),
        "test": (
            test_df,
            "test",
        ),
    }

    result = {}

    for split_name, (
        df,
        expected_value,
    ) in expected.items():

        observed = sorted(
            df[
                "model_split"
            ]
            .dropna()
            .astype(str)
            .unique()
            .tolist()
        )

        valid = (
            observed
            == [
                expected_value
            ]
        )

        result[
            split_name
        ] = {
            "expected_value": (
                expected_value
            ),
            "observed_values": (
                observed
            ),
            "valid": (
                valid
            ),
        }

    return result


# ============================================================
# REPORTE GENERAL
# ============================================================

def create_split_validation_report(
    train_df,
    validation_df,
    test_df,
):
    """
    Genera el reporte completo de validación de la Fase 3.

    Incluye:

    - tamaño de particiones;
    - existencia de imágenes;
    - presencia de clases;
    - dominio del target;
    - campos requeridos;
    - duplicados internos;
    - fuga por sample_id;
    - fuga por archivos idénticos;
    - coherencia de model_split.

    Guarda:

        results/phase3/split_validation.json

    Returns
    -------
    dict
        Reporte completo.
    """

    RESULTS_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    print(
        "\nValidando rutas de imágenes..."
    )

    image_path_validation = (
        validate_image_paths(
            train_df,
            validation_df,
            test_df,
        )
    )

    print(
        "Validando presencia de clases..."
    )

    class_validation = {
        "train": validate_all_classes(
            train_df,
            "train",
        ),
        "validation": validate_all_classes(
            validation_df,
            "validation",
        ),
        "test": validate_all_classes(
            test_df,
            "test",
        ),
    }

    print(
        "Validando dominio del target..."
    )

    target_validation = (
        validate_target_domain(
            train_df,
            validation_df,
            test_df,
        )
    )

    print(
        "Validando campos requeridos..."
    )

    required_fields_validation = (
        validate_required_fields(
            train_df,
            validation_df,
            test_df,
        )
    )

    print(
        "Validando duplicados internos..."
    )

    internal_duplicates = (
        validate_internal_duplicates(
            train_df,
            validation_df,
            test_df,
        )
    )

    print(
        "Validando solapamiento de sample_id..."
    )

    sample_id_validation = (
        validate_sample_ids(
            train_df,
            validation_df,
            test_df,
        )
    )

    print(
        "Validando columna model_split..."
    )

    model_split_validation = (
        validate_model_split_column(
            train_df,
            validation_df,
            test_df,
        )
    )

    # --------------------------------------------------------
    # SHA-256
    # --------------------------------------------------------

    print(
        "Calculando hashes SHA-256..."
    )

    train_hashed = (
        add_file_hashes(
            train_df
        )
    )

    validation_hashed = (
        add_file_hashes(
            validation_df
        )
    )

    test_hashed = (
        add_file_hashes(
            test_df
        )
    )

    print(
        "Comparando hashes entre particiones..."
    )

    hash_validation = (
        validate_hash_overlap(
            train_hashed,
            validation_hashed,
            test_hashed,
        )
    )

    # --------------------------------------------------------
    # RESUMEN DE CLASES
    # --------------------------------------------------------

    classes_present = {
        "train": sorted(
            int(value)
            for value
            in train_df[
                "Retinopathy grade"
            ].unique()
        ),
        "validation": sorted(
            int(value)
            for value
            in validation_df[
                "Retinopathy grade"
            ].unique()
        ),
        "test": sorted(
            int(value)
            for value
            in test_df[
                "Retinopathy grade"
            ].unique()
        ),
    }

    # --------------------------------------------------------
    # VALIDACIÓN GLOBAL
    # --------------------------------------------------------

    all_paths_exist = all(
        result[
            "all_images_exist"
        ]
        for result
        in image_path_validation.values()
    )

    all_classes_present = all(
        result[
            "all_expected_classes_present"
        ]
        for result
        in class_validation.values()
    )

    target_domain_valid = all(
        result[
            "valid"
        ]
        for result
        in target_validation.values()
    )

    required_fields_valid = all(
        result[
            "valid"
        ]
        for result
        in required_fields_validation.values()
    )

    no_internal_duplicates = all(
        result[
            "valid"
        ]
        for result
        in internal_duplicates.values()
    )

    model_split_valid = all(
        result[
            "valid"
        ]
        for result
        in model_split_validation.values()
    )

    no_sample_id_leakage = (
        sample_id_validation[
            "no_sample_id_leakage"
        ]
    )

    no_exact_image_leakage = (
        hash_validation[
            "no_exact_image_leakage"
        ]
    )

    overall_valid = all(
        [
            all_paths_exist,
            all_classes_present,
            target_domain_valid,
            required_fields_valid,
            no_internal_duplicates,
            model_split_valid,
            no_sample_id_leakage,
            no_exact_image_leakage,
        ]
    )

    # --------------------------------------------------------
    # REPORTE FINAL
    # --------------------------------------------------------

    report = {
        "dataset": "IDRiD",
        "phase": 3,
        "validation_type": (
            "Preparación de datos y control de fuga"
        ),

        "splits": {
            "train": len(
                    train_df
                ),
            "validation": len(
                    validation_df
                ),
            "test": len(
                    test_df
                ),
            "total": int(
                len(
                    train_df
                )
                + len(
                    validation_df
                )
                + len(
                    test_df
                )
            ),
        },

        "classes_present": (
            classes_present
        ),

        "class_validation": (
            class_validation
        ),

        "target_domain_validation": (
            target_validation
        ),

        "required_fields_validation": (
            required_fields_validation
        ),

        "image_path_validation": (
            image_path_validation
        ),

        "internal_duplicates": (
            internal_duplicates
        ),

        "sample_id_overlap": (
            sample_id_validation
        ),

        "sha256_overlap": (
            hash_validation
        ),

        "model_split_validation": (
            model_split_validation
        ),

        "summary": {
            "all_images_exist": (
                all_paths_exist
            ),
            "all_expected_classes_present": (
                all_classes_present
            ),
            "target_domain_valid": (
                target_domain_valid
            ),
            "required_fields_valid": (
                required_fields_valid
            ),
            "no_internal_duplicates": (
                no_internal_duplicates
            ),
            "model_split_valid": (
                model_split_valid
            ),
            "no_sample_id_leakage": (
                no_sample_id_leakage
            ),
            "no_exact_image_leakage": (
                no_exact_image_leakage
            ),
            "overall_validation_passed": (
                overall_valid
            ),
        },

        # Estas claves también se mantienen a nivel superior
        # para que reproduce.py pueda acceder fácilmente.
        "no_sample_id_leakage": (
            no_sample_id_leakage
        ),

        "no_exact_image_leakage": (
            no_exact_image_leakage
        ),
    }

    output_path = (
        RESULTS_DIR
        / "split_validation.json"
    )

    with open(
        output_path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            report,
            file,
            indent=4,
            ensure_ascii=False,
        )

    print(
        "\nReporte de validación guardado en:"
    )

    print(
        output_path
    )

    print(
        "\nResumen de validación:"
    )

    print(
        "Todas las imágenes existen:",
        all_paths_exist,
    )

    print(
        "Cinco clases presentes:",
        all_classes_present,
    )

    print(
        "Dominio del target válido:",
        target_domain_valid,
    )

    print(
        "Campos requeridos completos:",
        required_fields_valid,
    )

    print(
        "Sin duplicados internos:",
        no_internal_duplicates,
    )

    print(
        "model_split correcto:",
        model_split_valid,
    )

    print(
        "Sin fuga por sample_id:",
        no_sample_id_leakage,
    )

    print(
        "Sin imágenes idénticas entre splits:",
        no_exact_image_leakage,
    )

    print(
        "Validación global:",
        overall_valid,
    )

    return report