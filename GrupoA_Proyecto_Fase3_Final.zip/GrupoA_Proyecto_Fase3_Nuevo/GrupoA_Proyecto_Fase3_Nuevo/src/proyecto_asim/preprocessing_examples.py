from pathlib import Path

import matplotlib.pyplot as plt

from proyecto_asim.image_preprocessing import (
    load_rgb_image,
    preprocess_image,
)

FIGURES_DIR = Path(
    "figures",
    "phase3",
)


def generate_preprocessing_example(
    train_df,
):
    """
    Genera una figura comparando una imagen original
    con la imagen después del preprocesamiento.
    """

    FIGURES_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    first_row = train_df.iloc[0]

    image_path = first_row[
        "image_path"
    ]

    original = load_rgb_image(
        image_path
    )

    processed = preprocess_image(
        image_path
    )

    plt.figure(
        figsize=(10, 5)
    )

    plt.subplot(
        1,
        2,
        1,
    )

    plt.imshow(
        original
    )

    plt.title(
        "Imagen original"
    )

    plt.axis(
        "off"
    )

    plt.subplot(
        1,
        2,
        2,
    )

    plt.imshow(
        processed
    )

    plt.title(
        "Imagen preprocesada"
    )

    plt.axis(
        "off"
    )

    plt.tight_layout()

    output_path = (
        FIGURES_DIR
        / "preprocessing_example.png"
    )

    plt.savefig(
        output_path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    print(
        "Ejemplo de preprocesamiento guardado en:",
        output_path,
    )

    return output_path