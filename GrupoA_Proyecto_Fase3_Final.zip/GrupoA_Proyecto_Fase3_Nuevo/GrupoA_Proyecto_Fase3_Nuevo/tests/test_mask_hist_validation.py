import os

import cv2
import numpy as np

# Carga de una imagen de prueba directa...
# img_path = "data/raw/Localization/Localization/Original_Images/Training Set/IDRiD_291.jpg"
img_path = (
    "data/raw/Localization/Localization/Original_Images/Testing Set/IDRiD_005.jpg"
)
img = cv2.imread(img_path)

if img is not None:
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Umbral para separar el fondo negro exterior
    _, thresh = cv2.threshold(gray, 10, 255, cv2.THRESH_BINARY)

    # Limpieza morfológica
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=1)

    # Aplicación de la máscara a la imagen original...
    edited_image = cv2.bitwise_and(img, img, mask=mask)

    # Imagen de prueba para inspeccionarla en tu carpeta figures/
    os.makedirs("data/interim", exist_ok=True)
    cv2.imwrite("data/interim/test_mask.png", edited_image)
    cv2.imwrite("data/interim/mask_for_hist.png", mask)
    print(
        "Imágenes (enmascarada y máscara) guardadas en data/interim/ para verificación."
    )
