import json
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

from proyecto_asim.prepare_dataset import DATASET_VERSION

# ============================================================
# CONFIGURACIÓN
# ============================================================

IMAGE_WIDTH = 224
IMAGE_HEIGHT = 224

NORMALIZATION_DIVISOR = 255.0

RESULTS_DIR = Path(
    "results",
    "phase3",
)


# ============================================================
# CARGA DE IMAGEN
# ============================================================

def load_rgb_image(image_path):
    """
    Lee una imagen mediante OpenCV y la convierte de BGR a RGB.

    Parameters
    ----------
    image_path : str | Path
        Ruta de la imagen.

    Returns
    -------
    numpy.ndarray
        Imagen en formato RGB.
    """

    image_path = Path(
        image_path
    )

    if not image_path.exists():
        raise FileNotFoundError(
            f"No existe la imagen: {image_path}"
        )

    image = cv2.imread(
        str(
            image_path
        )
    )

    if image is None:
        raise ValueError(
            "OpenCV no pudo cargar la imagen: "
            f"{image_path}"
        )

    image = cv2.cvtColor(
        image,
        cv2.COLOR_BGR2RGB,
    )

    return image


# ============================================================
# RESIZE CON PADDING
# ============================================================

def resize_with_padding(
    image,
    target_width=IMAGE_WIDTH,
    target_height=IMAGE_HEIGHT,
):
    """
    Redimensiona una imagen preservando la relación de aspecto.

    La región sobrante se completa con fondo negro.

    Esto evita deformar directamente la anatomía de la retina
    al forzar una imagen rectangular a un tamaño cuadrado.

    Parameters
    ----------
    image : numpy.ndarray
        Imagen RGB.

    target_width : int
        Ancho final.

    target_height : int
        Alto final.

    Returns
    -------
    numpy.ndarray
        Imagen con tamaño target_height x target_width x 3.
    """

    if image is None:
        raise ValueError(
            "La imagen recibida es None."
        )

    if image.ndim != 3:
        raise ValueError(
            "La imagen debe tener tres dimensiones."
        )

    if image.shape[2] != 3:
        raise ValueError(
            "La imagen debe tener tres canales RGB."
        )

    original_height = image.shape[0]
    original_width = image.shape[1]

    if (
        original_height <= 0
        or original_width <= 0
    ):
        raise ValueError(
            "Dimensiones de imagen no válidas."
        )

    scale = min(
        target_width
        / original_width,
        target_height
        / original_height,
    )

    new_width = max(1, round(original_width * scale))

    new_height = max(1, round(original_height * scale))

    resized = cv2.resize(
        image,
        (
            new_width,
            new_height,
        ),
        interpolation=cv2.INTER_AREA,
    )

    canvas = np.zeros(
        (
            target_height,
            target_width,
            3,
        ),
        dtype=np.uint8,
    )

    x_offset = (
        target_width
        - new_width
    ) // 2

    y_offset = (
        target_height
        - new_height
    ) // 2

    canvas[
        y_offset:
        y_offset + new_height,
        x_offset:
        x_offset + new_width,
    ] = resized

    return canvas


# ============================================================
# NORMALIZACIÓN
# ============================================================

def normalize_image(image):
    """
    Convierte la imagen a float32 y normaliza los valores
    desde [0, 255] hasta [0, 1].

    Parameters
    ----------
    image : numpy.ndarray

    Returns
    -------
    numpy.ndarray
    """

    if image is None:
        raise ValueError(
            "La imagen recibida es None."
        )

    image = image.astype(
        np.float32
    )

    image = (
        image
        / NORMALIZATION_DIVISOR
    )

    return image


# ============================================================
# PIPELINE DE UNA IMAGEN
# ============================================================

def preprocess_image(image_path):
    """
    Ejecuta el preprocesamiento completo de una imagen.

    Etapas:
    1. Leer imagen.
    2. Convertir a RGB.
    3. Redimensionar preservando relación de aspecto.
    4. Aplicar padding.
    5. Convertir a float32.
    6. Normalizar a [0, 1].

    Returns
    -------
    numpy.ndarray
        Imagen final con forma 224 x 224 x 3.
    """

    image = load_rgb_image(
        image_path
    )

    image = resize_with_padding(
        image
    )

    image = normalize_image(
        image
    )

    return image


# ============================================================
# VALIDACIÓN DE UNA IMAGEN PREPROCESADA
# ============================================================

def validate_preprocessed_image(
    image,
):
    """
    Verifica que una imagen preprocesada cumpla:

    - forma 224 x 224 x 3;
    - dtype float32;
    - valores dentro de [0, 1].

    Returns
    -------
    dict
    """

    expected_shape = (
        IMAGE_HEIGHT,
        IMAGE_WIDTH,
        3,
    )

    shape_valid = (
        image.shape
        == expected_shape
    )

    dtype_valid = (
        image.dtype
        == np.float32
    )

    min_value = float(
        image.min()
    )

    max_value = float(
        image.max()
    )

    range_valid = (
        min_value >= 0.0
        and max_value <= 1.0
    )

    return {
        "expected_shape": list(
            expected_shape
        ),
        "observed_shape": list(
            image.shape
        ),
        "shape_valid": (
            shape_valid
        ),
        "expected_dtype": (
            "float32"
        ),
        "observed_dtype": str(
            image.dtype
        ),
        "dtype_valid": (
            dtype_valid
        ),
        "min_value": (
            min_value
        ),
        "max_value": (
            max_value
        ),
        "range_valid": (
            range_valid
        ),
        "valid": (
            shape_valid
            and dtype_valid
            and range_valid
        ),
    }


# ============================================================
# RESUMEN DE PREPROCESAMIENTO
# ============================================================

def create_preprocessing_summary(
    train_df,
    validation_df,
    test_df,
):
    """
    Ejecuta y valida el pipeline de preprocesamiento sobre
    todas las imágenes del dataset modelable.

    IMPORTANTE:
    Esta función no sobrescribe las imágenes originales.

    Guarda:
        results/phase3/preprocessing_summary.json

    El reporte incluye:
    - tamaño final;
    - canales;
    - color;
    - tipo de dato;
    - normalización;
    - imágenes procesadas;
    - errores;
    - mínimo y máximo observado.

    Returns
    -------
    dict
    """

    RESULTS_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    complete_df = pd.concat(
        [
            train_df,
            validation_df,
            test_df,
        ],
        ignore_index=True,
    )

    total_images = len(
        complete_df
    )

    successfully_processed = 0

    errors = []

    global_min = None
    global_max = None

    split_summary = {
        "train": {
            "total": len(
                train_df
            ),
            "processed": 0,
            "errors": 0,
        },
        "validation": {
            "total": len(
                validation_df
            ),
            "processed": 0,
            "errors": 0,
        },
        "test": {
            "total": len(
                test_df
            ),
            "processed": 0,
            "errors": 0,
        },
    }

    print(
        "\nValidando preprocesamiento "
        f"de {total_images} imágenes..."
    )

    for index, row in complete_df.iterrows():

        image_path = row[
            "image_path"
        ]

        sample_id = row[
            "sample_id"
        ]

        model_split = row[
            "model_split"
        ]

        try:

            image = preprocess_image(
                image_path
            )

            validation = (
                validate_preprocessed_image(
                    image
                )
            )

            if not validation[
                "valid"
            ]:
                raise ValueError(
                    "La imagen preprocesada "
                    "no cumple las validaciones: "
                    f"{validation}"
                )

            # Persistir el tensor ya preprocesado en la carpeta de su split.
            # Nunca se ajustan parámetros con validation/test: estas operaciones
            # son deterministas (resize + conversión RGB + /255).
            processed_root = (
                Path("data") / "processed" / DATASET_VERSION / "images" / str(model_split)
            )
            processed_root.mkdir(parents=True, exist_ok=True)
            output_name = Path(str(image_path)).stem + ".npy"
            np.save(processed_root / output_name, image.astype(np.float32, copy=False))

            current_min = float(
                image.min()
            )

            current_max = float(
                image.max()
            )

            if global_min is None:
                global_min = (
                    current_min
                )

            else:
                global_min = min(
                    global_min,
                    current_min,
                )

            if global_max is None:
                global_max = (
                    current_max
                )

            else:
                global_max = max(
                    global_max,
                    current_max,
                )

            successfully_processed += 1

            split_summary[
                model_split
            ][
                "processed"
            ] += 1

        except (
            FileNotFoundError,
            ValueError,
            cv2.error,
        ) as exc:

            split_summary[
                model_split
            ][
                "errors"
            ] += 1

            errors.append(
                {
                    "index": int(
                        index
                    ),
                    "sample_id": str(
                        sample_id
                    ),
                    "model_split": str(
                        model_split
                    ),
                    "image_path": str(
                        image_path
                    ),
                    "error": str(
                        exc
                    ),
                }
            )

    number_of_errors = len(
        errors
    )

    success_rate = 0.0

    if total_images > 0:
        success_rate = (
            successfully_processed
            / total_images
            * 100
        )

    summary = {
        "phase": 3,
        "dataset": "IDRiD",
        "preprocessing": {
            "image_size": [
                IMAGE_HEIGHT,
                IMAGE_WIDTH,
            ],
            "channels": 3,
            "color_space": "RGB",
            "output_dtype": (
                "float32"
            ),
            "normalization": (
                "pixel / 255.0"
            ),
            "expected_range": [
                0.0,
                1.0,
            ],
            "resize_strategy": (
                "Preservación de relación "
                "de aspecto con padding negro."
            ),
        },
        "image_size": [
            IMAGE_HEIGHT,
            IMAGE_WIDTH,
        ],
        "channels": 3,
        "color_space": "RGB",
        "output_dtype": (
            "float32"
        ),
        "normalization": (
            "pixel / 255.0"
        ),
        "expected_range": [
            0.0,
            1.0,
        ],
        "number_of_images": (
            total_images
        ),
        "processed_arrays_directory": f"data/processed/{DATASET_VERSION}/images/{{train,validation,test}}",
        "processed_array_format": "NumPy .npy, float32, RGB, 224x224x3, values in [0,1]",
        "successfully_processed": (
            successfully_processed
        ),
        "number_of_errors": (
            number_of_errors
        ),
        "success_rate_percent": round(
            success_rate,
            2,
        ),
        "observed_min": (
            global_min
        ),
        "observed_max": (
            global_max
        ),
        "split_summary": (
            split_summary
        ),
        "errors": (
            errors
        ),
    }

    output_path = (
        RESULTS_DIR
        / "preprocessing_summary.json"
    )

    with open(
        output_path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            summary,
            file,
            indent=4,
            ensure_ascii=False,
        )

    print(
        "\nResumen de preprocesamiento "
        "guardado en:"
    )

    print(
        output_path
    )

    print(
        "\nImágenes procesadas:"
    )

    print(
        f"{successfully_processed}"
        f"/{total_images}"
    )

    print(
        "Errores:"
    )

    print(
        number_of_errors
    )

    print(
        "Tasa de éxito:"
    )

    print(
        f"{success_rate:.2f}%"
    )

    if global_min is not None:
        print(
            "Mínimo observado:",
            global_min,
        )

    if global_max is not None:
        print(
            "Máximo observado:",
            global_max,
        )

    return summary