import os

import pandas as pd

RESULTS_DIR = "results"


def create_dqr(df, dataset_name):
    """Crea el Data Quality Report (DQR) em .csv. El DQR resume
    la calidad y características de cada variable del dataset.

    Para cada variable se calcula:

    - Tipo de dato.
    - Dominio o unidades.
    - Porcentaje de valores faltantes (% NA).
    - Número de valores únicos.
    - Mínimo.
    - Primer cuartil (Q1).
    - Mediana.
    - Tercer cuartil (Q3).
    - Máximo.
    """

    rows = []

    for column in df.columns:
        data = df[column]

        pct_na = data.isnull().sum() / len(data) * 100

        # Número de valores diferentes
        unique_values = data.nunique()

        # Los estadísticos como mínimo, mediana o máximo
        # solamente tienen sentido para variables numéricas.

        if pd.api.types.is_numeric_dtype(data):
            minimum = data.min()
            q1 = data.quantile(0.25)
            median = data.median()
            q3 = data.quantile(0.75)
            maximum = data.max()
        else:
            minimum = q1 = median = q3 = maximum = "N/A"

        # Definición del dominio y unidades
        if column == "Retinopathy grade":
            domain = "Grado ordinal 0-4"

        elif column == "Risk of macular edema":
            domain = "Grado ordinal 0-2"

        elif column == "Image name":
            domain = "Identificador"

        else:
            domain = "No aplica"

        # Adición de resultados a la tabla
        rows.append(
            {
                "Variable": column,
                "Tipo": str(data.dtype),
                "Dominio / Unidades": domain,
                "%NA": round(pct_na, 2),
                "Unicos": unique_values,
                "Min": minimum,
                "Q1": q1,
                "Mediana": median,
                "Q3": q3,
                "Max": maximum,
            }
        )

    # Convertir resultados en DataFrame
    dqr = pd.DataFrame(rows)
    output_path = os.path.join(RESULTS_DIR, f"dqr_summary_{dataset_name.lower()}.csv")
    dqr.to_csv(output_path, index=False)
    print(f"Tabla DQR guardada en: {output_path}")

    return dqr


def create_data_dictionary():
    """Crea el diccionario de datos, donde se explica qué significa
    cada variable utilizada en el proyecto. Contiene: Nombre, descripción,
    Tipo, Dominio / unidades, Fuente y Notas."""

    dictionary = pd.DataFrame(
        {
            "Nombre": [
                "Image name",
                "Retinopathy grade",
                "Risk of macular edema",
            ],
            "Descripcion": [
                ("Identificador asignado a cada imagen de fondo de ojo."),
                ("Grado de severidad de la retinopatía diabética."),
                ("Nivel de riesgo de edema macular asociado a la imagen."),
            ],
            "Tipo": [
                "Texto",
                "Entero ordinal",
                "Entero ordinal",
            ],
            "Dominio / Unidades": [
                "Identificador",
                "0, 1, 2, 3, 4",
                "0, 1, 2",
            ],
            "Fuente": [
                "IDRiD",
                "IDRiD",
                "IDRiD",
            ],
            "Notas": [
                ("Permite relacionar la etiqueta con la imagen correspondiente."),
                ("Variable objetivo principal del proyecto."),
                ("Variable clínica adicional. No corresponde al target principal."),
            ],
        }
    )

    # Guardar diccionario
    output_path = os.path.join(RESULTS_DIR, "diccionario_datos.csv")
    dictionary.to_csv(output_path, index=False)
    print(f"\nDiccionario de datos guardado en: {output_path}")

    return dictionary


def create_validity_risks():
    """Crea una tabla con los principales riesgos de validez
    identificados para el proyecto. Esta función NO detecta
    automáticamente los riesgos, su objetivo es documentarlos
    de forma organizada para el informe de la Fase 2."""

    risks = pd.DataFrame(
        {
            "Riesgo": [
                "Fuga de información",
                "Desbalance de clases",
                "Sesgo de selección",
                "Dependencia del conjunto de prueba",
            ],
            "Descripcion": [
                (
                    "Puede ocurrir si información utilizada "
                    "para evaluar el modelo también aparece "
                    "durante el entrenamiento."
                ),
                ("Algunas clases pueden contener muchas más imágenes que otras."),
                (
                    "El dataset representa una población "
                    "y condiciones de adquisición específicas."
                ),
                (
                    "El conjunto de prueba no debe utilizarse "
                    "para tomar decisiones durante el desarrollo "
                    "del modelo."
                ),
            ],
            "Posible consecuencia": [
                ("Obtener resultados artificialmente altos durante la evaluación."),
                (
                    "El modelo puede aprender mejor las clases "
                    "mayoritarias y tener menor desempeño "
                    "en las minoritarias."
                ),
                (
                    "El modelo podría no generalizar de la misma "
                    "forma a otras poblaciones o dispositivos."
                ),
                (
                    "Se puede sobreajustar indirectamente "
                    "el desarrollo al conjunto de prueba."
                ),
            ],
            "Mitigacion": [
                ("Mantener separados los conjuntos de entrenamiento y prueba."),
                (
                    "Analizar el desempeño por clase y considerar "
                    "estrategias de balance en fases posteriores."
                ),
                ("Documentar la procedencia de los datos y reconocer esta limitación."),
                ("Reservar el conjunto de prueba para la evaluación final."),
            ],
        }
    )

    output_path = os.path.join(RESULTS_DIR, "riesgos_validez.csv")
    risks.to_csv(output_path, index=False)
    print(f"\nRiesgos guardados en: {output_path}")

    return risks


def create_class_summary(df, dataset_name):
    """Genera una tabla con la cantidad y porcentaje de imágenes para cada grado
    de retinopatía, lo que permite observar posibles desbalances entre las clases."""

    # Cantidad de imágenes por clase.
    counts = df["Retinopathy grade"].value_counts().sort_index()
    # Porcentaje por clase.
    percentages = (
        df["Retinopathy grade"].value_counts(normalize=True).sort_index() * 100
    )

    summary = pd.DataFrame(
        {
            "Grado": counts.index,
            "Cantidad": counts.values,
            "Porcentaje (%)": percentages.round(2).values,
        }
    )

    output_path = os.path.join(
        RESULTS_DIR, f"resumen_clases_{dataset_name.lower()}.csv"
    )
    summary.to_csv(output_path, index=False)
    print(f"\nResumen de distribución guardado en: {output_path}")

    return summary
