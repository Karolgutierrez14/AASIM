import json
import os

RESULTS_DIR = "results"
# Columnas que esperamos encontrar en el dataset
EXPECTED_COLUMNS = [
    "Image name",
    "Retinopathy grade",
    "Risk of macular edema",
]


def validate_columns(df):
    """Verifica que el dataset tenga las variables esperadas.

    Variables necesarias: Image name, Retinopathy grade &
    Risk of macular edema."""

    missing_columns = []

    for column in EXPECTED_COLUMNS:
        if column not in df.columns:
            missing_columns.append(column)

    if len(missing_columns) == 0:
        print("Todas las columnas esperadas están presentes.")
    else:
        print("Faltan las siguientes columnas:")
        for column in missing_columns:
            print("-", column)
    return missing_columns


# Validación del grado de retinopatía
def validate_retinopathy_grade(df, dataset_name):
    """Verifica que Retinopathy grade tenga únicamente valores permitidos.

    Dominio esperado:
    0 = Sin retinopatía diabética
    1 = Retinopatía diabética leve
    2 = Retinopatía diabética moderada
    3 = Retinopatía diabética severa
    4 = Retinopatía diabética proliferativa
    """

    valid_values = [0, 1, 2, 3, 4]

    invalid_rows = df[~df["Retinopathy grade"].isin(valid_values)]

    print(f"VALIDACIÓN DE RETINOPATHY GRADE - {dataset_name}")

    if len(invalid_rows) > 0:
        print("\nRegistros encontrados:")
        print(invalid_rows)
    return invalid_rows


# Validación del edema macular
def validate_macular_edema(df, dataset_name):
    """Verifica que Risk of macular edema tenga únicamente valores permitidos.

    Dominio esperado:
    0
    1
    2
    """

    valid_values = [0, 1, 2]

    invalid_rows = df[~df["Risk of macular edema"].isin(valid_values)]

    print(f"VALIDACIÓN DE EDEMA MACULAR - {dataset_name}")

    if len(invalid_rows) > 0:
        print("\nRegistros encontrados:")
        print(invalid_rows)
    return invalid_rows


# Validación de identificadores vacíos
def validate_image_names(df, dataset_name):
    """Comprueba que todas las imágenes tengan un identificador.
    Image name permite relacionar cada registro del CSV con su
    imagen correspondiente."""

    empty_names = df[df["Image name"].isnull()]

    print(f"VALIDACIÓN DE IMAGE NAME - {dataset_name}")

    return empty_names


# Revisión de duplicados
def validate_duplicates(df, dataset_name):
    """Busca identificadores repetidos dentro del mismo conjunto.
    Un identificador duplicado significa que el mismo Image name
    aparece más de una vez."""

    duplicates = df[df["Image name"].duplicated(keep=False)]

    print(f"DUPLICADOS - {dataset_name}")

    if len(duplicates) > 0:
        print("\nDuplicados encontrados:")
        print(
            duplicates[
                [
                    "Image name",
                    "Retinopathy grade",
                    "Risk of macular edema",
                ]
            ]
        )

    return duplicates


# Generación del resumen de validación
def create_validation_summary(df_train, df_test):
    """Ejecuta todas las validaciones y guarda un
    resumen de los resultados en formato JSON."""

    train_missing_columns = validate_columns(df_train)
    train_invalid_retinopathy = validate_retinopathy_grade(df_train, "TRAIN")
    train_invalid_edema = validate_macular_edema(df_train, "TRAIN")
    train_empty_names = validate_image_names(df_train, "TRAIN")
    train_duplicates = validate_duplicates(df_train, "TRAIN")

    test_missing_columns = validate_columns(df_test)
    test_invalid_retinopathy = validate_retinopathy_grade(df_test, "TEST")
    test_invalid_edema = validate_macular_edema(df_test, "TEST")
    test_empty_names = validate_image_names(df_test, "TEST")
    test_duplicates = validate_duplicates(df_test, "TEST")

    summary = {
        "dataset": "IDRiD",
        "section": "Disease_Grading",
        "training": {
            "number_of_records": len(df_train),
            "missing_columns": train_missing_columns,
            "invalid_retinopathy_grade": len(train_invalid_retinopathy),
            "invalid_macular_edema": len(train_invalid_edema),
            "empty_image_names": len(train_empty_names),
            "duplicate_image_names": len(train_duplicates),
        },
        "testing": {
            "number_of_records": len(df_test),
            "missing_columns": test_missing_columns,
            "invalid_retinopathy_grade": len(test_invalid_retinopathy),
            "invalid_macular_edema": len(test_invalid_edema),
            "empty_image_names": len(test_empty_names),
            "duplicate_image_names": len(test_duplicates),
        },
    }

    output_path = os.path.join(RESULTS_DIR, "validation_report.json")
    with open(output_path, "w", encoding="utf-8") as file:
        json.dump(summary, file, indent=4, ensure_ascii=False)

    print(f"\nReporte de Validación guardado en: {output_path}")

    return summary
