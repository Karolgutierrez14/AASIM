import json
from pathlib import Path

import pandas as pd

RESULTS_DIR = Path(
    "results",
    "phase3",
)


def generate_phase3_summary():
    """
    Une los principales resultados de Fase 3
    en un único archivo JSON.
    """

    distribution_path = (
        RESULTS_DIR
        / "class_distribution.csv"
    )

    validation_path = (
        RESULTS_DIR
        / "split_validation.json"
    )

    preprocessing_path = (
        RESULTS_DIR
        / "preprocessing_summary.json"
    )

    if not distribution_path.exists():
        raise FileNotFoundError(
            distribution_path
        )

    if not validation_path.exists():
        raise FileNotFoundError(
            validation_path
        )

    if not preprocessing_path.exists():
        raise FileNotFoundError(
            preprocessing_path
        )

    distribution = pd.read_csv(
        distribution_path
    )

    with open(
        validation_path,
        encoding="utf-8",
    ) as file:
        validation = json.load(
            file
        )

    with open(
        preprocessing_path,
        encoding="utf-8",
    ) as file:
        preprocessing = json.load(
            file
        )

    summary = {
        "phase": 3,
        "dataset": "IDRiD",
        "task": (
            "Clasificación multiclase "
            "de retinopatía diabética"
        ),
        "splits": validation[
            "splits"
        ],
        "classes_present": validation[
            "classes_present"
        ],
        "no_sample_id_leakage": (
            validation[
                "no_sample_id_leakage"
            ]
        ),
        "no_exact_image_leakage": (
            validation[
                "no_exact_image_leakage"
            ]
        ),
        "image_size": preprocessing[
            "image_size"
        ],
        "color_space": preprocessing[
            "color_space"
        ],
        "normalization": preprocessing[
            "normalization"
        ],
        "successfully_processed": (
            preprocessing[
                "successfully_processed"
            ]
        ),
        "processing_errors": (
            preprocessing[
                "number_of_errors"
            ]
        ),
        "class_distribution": (
            distribution.to_dict(
                orient="records"
            )
        ),
    }

    output_path = (
        RESULTS_DIR
        / "phase3_summary.json"
    )

    with open(
        output_path,
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            summary,
            file,
            indent=4,
            ensure_ascii=False,
        )

    # Generar un bloque LaTeX con los resultados reales de esta ejecución.
    # El informe lo incluye automáticamente cuando se compila desde la raíz.
    tex_lines = [
        r"\section*{Resultados reales de la ejecución de Fase 3}",
        r"\noindent Estos valores se generaron automáticamente a partir de los artefactos del pipeline.",
        r"\begin{itemize}",
        rf"  \item Train: {validation['splits'].get('train', 'N/D')} registros.",
        rf"  \item Validation: {validation['splits'].get('validation', 'N/D')} registros.",
        rf"  \item Test oficial: {validation['splits'].get('test', 'N/D')} registros.",
        rf"  \item IDs sin solapamiento entre particiones: {('Sí' if validation.get('no_sample_id_leakage') else 'No')}.",
        rf"  \item Archivos sin identidad binaria entre particiones: {('Sí' if validation.get('no_exact_image_leakage') else 'No')}.",
        rf"  \item Imágenes procesadas: {preprocessing.get('successfully_processed', 'N/D')} de {preprocessing.get('number_of_images', 'N/D')}.",
        rf"  \item Errores de preprocesamiento: {preprocessing.get('number_of_errors', 'N/D')}.",
        r"\end{itemize}",
        r"\noindent Distribución por clase: archivo \texttt{results/phase3/class\_distribution.csv}. El detalle anti-fuga está en \texttt{results/phase3/split\_validation.json} y el detalle de histogramas en \texttt{results/phase3/histograms/histogram\_summary.csv}.",
    ]
    tex_path = RESULTS_DIR / "phase3_results.tex"
    tex_path.write_text("\n".join(tex_lines) + "\n", encoding="utf-8")

    print(
        "Resumen general de Fase 3:",
        output_path,
    )
    print("Fragmento LaTeX de resultados:", tex_path)

    return summary