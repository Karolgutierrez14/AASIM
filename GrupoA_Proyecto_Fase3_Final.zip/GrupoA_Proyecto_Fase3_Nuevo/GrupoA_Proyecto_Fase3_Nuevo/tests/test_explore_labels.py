import json
import os

import pytest

from proyecto_asim.explore_labels import (
    load_and_clean_data,
    plot_edema_distribution,
    plot_retinopathy_distribution,
    save_exploration_summary,
    show_edema_distribution,
    show_retinopathy_distribution,
)


@pytest.fixture(autouse=True)
def mock_idrid_data(monkeypatch, tmp_path):
    """
    Crea la estructura de carpetas y archivos CSV falsos en el entorno temporal,
    y redirige el directorio de trabajo actual para aislar la prueba.
    """
    # Cambiamos al directorio temporal
    monkeypatch.chdir(tmp_path)

    # Creamos físicamente las carpetas que el código original busca
    os.makedirs(
        os.path.join("data", "raw", "Disease_Grading", "Groundtruths"), exist_ok=True
    )
    os.makedirs("results", exist_ok=True)
    os.makedirs("figures", exist_ok=True)

    # Datos falsos con la estructura exacta de IDRiD
    fake_train_csv = (
        "Image name, Retinopathy grade , Risk of macular edema, Unnamed: 3\n"
        "ID_001, 0, 1, \n"
        "ID_002, 2, 0, \n"
        "ID_003, 2, 2, \n"
    )
    fake_test_csv = (
        "Image name, Retinopathy grade, Risk of macular edema\nID_101, 1, 0\n"
    )

    # Escribimos los archivos en las rutas exactas que usa explore_labels.py
    train_path = os.path.join(
        "data",
        "raw",
        "Disease_Grading",
        "Groundtruths",
        "IDRiD_Disease Grading_Training Labels.csv",
    )
    test_path = os.path.join(
        "data",
        "raw",
        "Disease_Grading",
        "Groundtruths",
        "IDRiD_Disease Grading_Testing Labels.csv",
    )

    with open(train_path, "w", encoding="utf-8") as f:
        f.write(fake_train_csv)

    with open(test_path, "w", encoding="utf-8") as f:
        f.write(fake_test_csv)


def test_load_and_clean_data():
    """Verifica la carga, el recorte de espacios y la eliminación de columnas 'Unnamed'."""
    df_train, df_test = load_and_clean_data()

    assert "Image name" in df_train.columns
    assert "Retinopathy grade" in df_train.columns
    assert not any(col.startswith("Unnamed") for col in df_train.columns)
    assert len(df_train) == 3
    assert len(df_test) == 1


def test_save_exploration_summary():
    """Verifica que el resumen JSON se genere con las claves y métricas correctas."""
    df_train, df_test = load_and_clean_data()
    save_exploration_summary(df_train, df_test)

    json_path = os.path.join("results", "exploration_summary.json")
    assert os.path.exists(json_path), (
        "El archivo exploration_summary.json no fue creado."
    )

    with open(json_path, "r", encoding="utf-8") as f:
        summary = json.load(f)

    assert summary["dataset"] == "IDRiD"
    assert summary["number_of_samples"]["training"] == 3
    assert summary["number_of_samples"]["testing"] == 1
    assert summary["number_of_samples"]["total"] == 4


def test_show_distributions():
    """Verifica el cálculo de conteos y porcentajes para retinopatía y edema."""
    df_train, _ = load_and_clean_data()

    df_ret = show_retinopathy_distribution(df_train)
    assert "Cantidad" in df_ret.columns
    assert "Porcentaje (%)" in df_ret.columns
    assert df_ret.index.name == "Retinopathy grade"

    df_edema = show_edema_distribution(df_train)
    assert "Cantidad" in df_edema.columns
    assert "Porcentaje (%)" in df_edema.columns
    assert df_edema.index.name == "Risk of macular edema"


def test_plots_generation():
    """Verifica que las funciones grafiquen y guarden correctamente los archivos PNG."""
    df_train, df_test = load_and_clean_data()

    plot_retinopathy_distribution(df_train, df_test)
    plot_edema_distribution(df_train, df_test)

    plot1 = os.path.join("figures", "retinopathy_grade_dist.png")
    plot2 = os.path.join("figures", "macular_edema_dist.png")

    assert os.path.exists(plot1), "No se generó la gráfica de retinopatía."
    assert os.path.exists(plot2), "No se generó la gráfica de edema macular."

    assert os.path.getsize(plot1) > 0, "La gráfica de retinopatía está vacía (0 bytes)."
    assert os.path.getsize(plot2) > 0, (
        "La gráfica de edema macular está vacía (0 bytes)."
    )
