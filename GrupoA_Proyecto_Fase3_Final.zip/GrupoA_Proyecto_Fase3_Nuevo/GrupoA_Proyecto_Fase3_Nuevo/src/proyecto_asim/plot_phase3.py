from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

RESULTS_DIR = Path("results", "phase3")
FIGURES_DIR = Path("figures", "phase3")


def plot_split_distribution():
    """
    Genera una figura con la distribución de Retinopathy grade
    para train, validation y test.
    """

    input_path = (
        RESULTS_DIR
        / "class_distribution.csv"
    )

    if not input_path.exists():
        raise FileNotFoundError(
            f"No existe {input_path}"
        )

    df = pd.read_csv(
        input_path
    )

    FIGURES_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    pivot = df.pivot(
        index="Retinopathy grade",
        columns="Split",
        values="Cantidad",
    )

    ax = pivot.plot(
        kind="bar",
        figsize=(9, 5),
    )

    ax.set_title(
        "Distribución de clases por partición"
    )

    ax.set_xlabel(
        "Grado de retinopatía diabética"
    )

    ax.set_ylabel(
        "Número de imágenes"
    )

    ax.legend(
        title="Partición"
    )

    plt.xticks(
        rotation=0
    )

    plt.tight_layout()

    output_path = (
        FIGURES_DIR
        / "class_distribution_splits.png"
    )

    plt.savefig(
        output_path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    print(
        "Figura guardada en:",
        output_path,
    )

    return output_path