import json
import os

import matplotlib.pyplot as plt
import pandas as pd

# Definición de rutas del proyecto.
BASE_DIR = os.path.join("data", "raw", "Disease_Grading")
GROUNDTRUTHS_DIR = os.path.join(BASE_DIR, "Groundtruths")

# Archivo de entrenamiento.
TRAIN_CSV = os.path.join(GROUNDTRUTHS_DIR, "IDRiD_Disease Grading_Training Labels.csv")

# Archivo de prueba.
TEST_CSV = os.path.join(GROUNDTRUTHS_DIR, "IDRiD_Disease Grading_Testing Labels.csv")

# Carpetas donde se guardarán resultados y figuras.
RESULTS_DIR = "results"
FIGURES_DIR = "figures"


# Carga y Limpieza de Datos
def load_and_clean_data():
    """Carga y limpia los datasets de entrenamiento
    y prueba de etiquetas del dataset IDRiD.

    Retorna:
        df_train: DataFrame de entrenamiento.
        df_test: DataFrame de prueba.
    """

    # Verificación de existencia de los archivos...
    if not os.path.exists(TRAIN_CSV):
        raise FileNotFoundError(f"No se encontró el archivo:{TRAIN_CSV}")

    if not os.path.exists(TEST_CSV):
        raise FileNotFoundError(f"No se encontró el archivo:{TEST_CSV}")

    # Lectura de los archivos CSV
    df_train = pd.read_csv(TRAIN_CSV)
    df_test = pd.read_csv(TEST_CSV)

    # NOTA DE CALIDAD DE DATOS:
    # - Hallazgo: El CSV de entrenamiento original contiene comas sobrantes al final
    #   de las líneas, lo que genera columnas vacías ("Unnamed: 3" a "Unnamed: 11").

    # - Hallazgo: El CSV de prueba no presenta esta anomalía.

    # - Acción correctiva: Se limpian los espacios en blanco en los nombres de las
    #   columnas y se eliminan las columnas "Unnamed" para evitar errores en el modelo.

    # Retiro de espacios de los nombres de las columnas.
    df_train.columns = df_train.columns.str.strip()
    df_test.columns = df_test.columns.str.strip()

    df_train = df_train.loc[:, ~df_train.columns.str.contains("^Unnamed")]

    return df_train, df_test


def save_exploration_summary(df_train, df_test):
    """Calcula todas las métricas y distribuciones del dataset

    Permite conocer:
    - Número de imágenes de entrenamiento.
    - Número de imágenes de prueba.
    - Número total de registros.
    - Variables disponibles.
    """

    summary = {
        "dataset": "IDRiD",
        "section": "Disease_Grading",
        "number_of_samples": {
            "training": len(df_train),
            "testing": len(df_test),
            "total": len(df_train) + len(df_test),
        },
        "variables": df_train.columns.tolist(),
        "missing_values": {
            "training": df_train.isnull().sum().to_dict(),
            "testing": df_test.isnull().sum().to_dict(),
        },
        "retinopathy_grade_distribution": {
            "training": df_train["Retinopathy grade"]
            .value_counts()
            .sort_index()
            .to_dict(),
            "testing": df_test["Retinopathy grade"]
            .value_counts()
            .sort_index()
            .to_dict(),
        },
        "macular_edema_distribution": {
            "training": df_train["Risk of macular edema"]
            .value_counts()
            .sort_index()
            .to_dict(),
            "testing": df_test["Risk of macular edema"]
            .value_counts()
            .sort_index()
            .to_dict(),
        },
        "data_quality_note": (
            "El archivo CSV original de entrenamiento "
            "presentó columnas vacías tipo 'Unnamed'. "
            "Estas columnas fueron eliminadas durante "
            "la limpieza inicial."
        ),
    }

    output_path = os.path.join(RESULTS_DIR, "exploration_summary.json")
    with open(output_path, "w", encoding="utf-8") as file:
        json.dump(summary, file, indent=4, ensure_ascii=False)

    print(f"Resumen guardado en: {output_path}")


# DISTRIBUCIÓN DEL GRADO DE RETINOPATÍA
def show_retinopathy_distribution(df):
    """Calcula cuántas imágenes existen en cada grado de retinopatía
    diabética. Los grados corresponden a una escala ordinal:

    0 = Sin retinopatía diabética
    1 = Retinopatía diabética leve
    2 = Retinopatía diabética moderada
    3 = Retinopatía diabética severa
    4 = Retinopatía diabética proliferativa
    """

    counts = df["Retinopathy grade"].value_counts().sort_index()

    percentages = (
        df["Retinopathy grade"].value_counts(normalize=True).sort_index() * 100
    )

    distribution = pd.DataFrame(
        {"Cantidad": counts, "Porcentaje (%)": percentages.round(2)}
    )

    distribution.index.name = "Retinopathy grade"

    return distribution


# DISTRIBUCIÓN DEL RIESGO DE EDEMA MACULAR
def show_edema_distribution(df):
    """Calcula cuántas imágenes existen en cada categoría de riesgo de
    edema macular. La variable utiliza valores ordinales entre 0 y 2."""

    counts = df["Risk of macular edema"].value_counts().sort_index()

    percentages = (
        df["Risk of macular edema"].value_counts(normalize=True).sort_index() * 100
    )

    distribution = pd.DataFrame(
        {"Cantidad": counts, "Porcentaje (%)": percentages.round(2)}
    )

    distribution.index.name = "Risk of macular edema"

    return distribution


# GRÁFICA DE RETINOPATÍA
def plot_retinopathy_distribution(df_train, df_test):
    """Compara gráficamente la distribución de los grados
    de retinopatía entre entrenamiento y prueba."""

    train_counts = df_train["Retinopathy grade"].value_counts().sort_index()
    test_counts = df_test["Retinopathy grade"].value_counts().sort_index()

    distribution = pd.DataFrame(
        {"Training": train_counts, "Testing": test_counts}
    ).fillna(0)

    distribution.plot(kind="bar", figsize=(8, 5), rot=0)
    plt.title("Distribución de grados de retinopatía")
    plt.xlabel("Grado de retinopatía diabética")
    plt.ylabel("Número de imágenes")
    plt.tight_layout()

    output_path = os.path.join(FIGURES_DIR, "retinopathy_grade_dist.png")

    plt.savefig(output_path, dpi=300)
    plt.close()

    print(f"\nGráfica guardada en: {output_path}")


# GRÁFICA DE EDEMA MACULAR
def plot_edema_distribution(df_train, df_test):
    """Compara la distribución del riesgo de
    edema macular entre entrenamiento y prueba."""

    train_counts = df_train["Risk of macular edema"].value_counts().sort_index()
    test_counts = df_test["Risk of macular edema"].value_counts().sort_index()

    distribution = pd.DataFrame(
        {"Training": train_counts, "Testing": test_counts}
    ).fillna(0)

    distribution.plot(kind="bar", figsize=(8, 5), rot=0)
    plt.title("Distribución del riesgo de edema macular")
    plt.xlabel("Nivel de riesgo de edema macular")
    plt.ylabel("Número de imágenes")
    plt.tight_layout()

    output_path = os.path.join(FIGURES_DIR, "macular_edema_dist.png")

    plt.savefig(output_path, dpi=300)
    plt.close()
    print(f"Gráfica guardada en: {output_path}")
