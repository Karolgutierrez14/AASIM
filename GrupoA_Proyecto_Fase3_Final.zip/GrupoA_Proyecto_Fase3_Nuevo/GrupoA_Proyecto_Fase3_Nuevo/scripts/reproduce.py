import os

from proyecto_asim.explore_labels import (
    load_and_clean_data,
    plot_edema_distribution,
    plot_retinopathy_distribution,
    save_exploration_summary,
    show_edema_distribution,
    show_retinopathy_distribution,
)
from proyecto_asim.generate_dqr import (
    create_class_summary,
    create_data_dictionary,
    create_dqr,
    create_validity_risks,
)
from proyecto_asim.image_preprocessing import (
    create_preprocessing_summary,
)
from proyecto_asim.pixel_classification import (
    generate_pixel_intensity_reports,
)


# FASE 3
from proyecto_asim.prepare_dataset import (
    DATASET_VERSION,
    create_modelable_dataset,
)
from proyecto_asim.validate_data import (
    create_validation_summary,
)
from proyecto_asim.validate_splits import (
    create_split_class_distribution,
    create_split_validation_report,
)


def main():
    """
    Pipeline reproducible del Proyecto ASIM.

    FASE 2 - Entendimiento de los datos:
    1. Carga y limpieza.
    2. Exploración de etiquetas.
    3. Distribución de clases.
    4. Figuras.
    5. Histogramas RGB.
    6. Validación.
    7. Data Quality Report.
    8. Diccionario de datos.
    9. Riesgos de validez.

    FASE 3 - Preparación de los datos:
    10. Asociación entre imágenes y etiquetas.
    11. Creación del dataset modelable.
    12. División estratificada 70/30 del Training Set oficial.
    13. Unión del 30 % retenido con el Testing Set oficial para crear test combinado.
    14. Análisis de distribución por clase.
    15. Validación de fuga de información.
    16. Validación del preprocesamiento de imágenes.
    """

 
    # CREAR CARPETAS DE RESULTADOS
    os.makedirs("results", exist_ok=True)
    os.makedirs("figures", exist_ok=True)
    os.makedirs(os.path.join("results", "phase3"), exist_ok=True)

   
    print("RETINOPATÍA DIABÉTICA - IDRiD")


    # CARGA DE DATOS
    df_train, df_test = (load_and_clean_data())

    # Datos de portada para el informe: se regeneran en cada ejecución.
    os.makedirs("results", exist_ok=True)

    phase2_tex = [
        rf"\newcommand{{\NumTrain}}{{{len(df_train)}}}",
        rf"\newcommand{{\NumTest}}{{{len(df_test)}}}",
        rf"\newcommand{{\NumTotal}}{{{len(df_train) + len(df_test)}}}",
        r"\newcommand{\DQRTrainRows}{}",
        r"\newcommand{\DQRTestRows}{}",
        r"\newcommand{\DataDictionaryRows}{}",
        r"\newcommand{\EdemaDistributionRows}{}",
        r"\newcommand{\RetinopathyDistributionRows}{}",
        r"\newcommand{\ValidityRiskRows}{}",
        r"\newcommand{\MissingTrain}{Consulte results/exploration_summary.json}",
        r"\newcommand{\MissingTest}{Consulte results/exploration_summary.json}",
        r"\newcommand{\RetClassOnePct}{Consulte results/exploration_summary.json}",
        r"\newcommand{\RetClassOneTotal}{Consulte results/exploration_summary.json}",
    ]
    with open("results/fase2_resultados.tex", "w", encoding="utf-8") as report_file:
        report_file.write("\n".join(phase2_tex) + "\n")

    print(
        "Total: "
        f"{len(df_train) + len(df_test)}"
    )

    # FASE 2
    print("FASE 2 - ENTENDIMIENTO DE LOS DATOS")

    # Distribución de retinopatía
    train_retinopathy = (show_retinopathy_distribution(df_train))

    test_retinopathy = (show_retinopathy_distribution(df_test))

    print("\nTRAIN:")
    print(train_retinopathy)

    print("\nTEST:")
    print(test_retinopathy)


    #Distribución de edema macular
    print("\nDISTRIBUCIÓN DE EDEMA MACULAR")
    #train_edema = (show_edema_distribution(df_train))
    #test_edema = (show_edema_distribution(df_test))

    #print("\nTRAIN:")
    #print(train_edema)

    #print("\nTEST:")
    #print(test_edema)


    # 4. Resumen general
    print("\nRESUMEN DE EXPLORACIÓN")
    save_exploration_summary(df_train, df_test)


    # 5. Gráficas
    print("\nGENERANDO GRÁFICAS DE DISTRIBUCIÓN")

    plot_retinopathy_distribution(df_train, df_test)
    plot_edema_distribution(df_train, df_test)

    # Los histogramas de imagen se calculan después de crear el split 70/30.

  
    # 7. Validación
    print("\nVALIDACIÓN DE CALIDAD Y CONSISTENCIA")
    create_validation_summary(df_train, df_test)

    
    # 8. Data Quality Report
    print("\nDATA QUALITY REPORT")

    create_dqr(df_train, "TRAIN")
    create_dqr(df_test, "TEST")


    # 9. Resumen de clases
    print("\nRESUMEN DE CLASES")

    create_class_summary(df_train, "TRAIN")
    create_class_summary(df_test, "TEST")


    # 10. Diccionario de datos
    print("\nDICCIONARIO DE DATOS")
    create_data_dictionary()


    # 11. Riesgos de validez
    print("\n[11] RIESGOS DE VALIDEZ")
    create_validity_risks()


    # FASE 3
    print("FASE 3 - PREPARACIÓN DE LOS DATOS")

    # Dataset modelable
    print("\nCREACIÓN DEL DATASET MODELABLE")

    (train_model, validation_model, test_model) = create_modelable_dataset(df_train, df_test)

    print("\nCantidad de registros después de la preparación:")
    print(f"Train: {len(train_model)}")

    print(f"Validation independiente: {len(validation_model)} (no se usa en este enfoque)")
    print(f"Test: {len(test_model)}")

    # Histogramas calculados SOLO con el 70 % de entrenamiento ya separado.
    print("\n HISTOGRAMAS RGB DEL TRAIN 70 %")
    generate_pixel_intensity_reports(train_model)

    print(
        "Total: "
        f"{len(train_model) + len(validation_model) + len(test_model)}"
    )


    # 13. Distribución por clases
    print("\nDISTRIBUCIÓN DE CLASES POR PARTICIÓN")

    class_distribution = (
        create_split_class_distribution(
            train_model,
            validation_model,
            test_model,
        )
    )

    print("\nDistribución generada:")
    print(class_distribution)


    # 14. Validación anti-fuga
    print("\nVALIDACIÓN DE FUGA DE INFORMACIÓN")

    split_validation = (
        create_split_validation_report(
            train_model,
            validation_model,
            test_model,
        )
    )

    print("\nNo fuga por sample_id:")
    print(split_validation["no_sample_id_leakage"])
    print("\nNo existen imágenes exactamente iguales entre particiones:")
    print(split_validation["no_exact_image_leakage"])
    print("\nClases presentes en cada partición:")
    print(split_validation["classes_present"])


    # 15. Preprocesamiento
    print("\nVALIDACIÓN DEL PREPROCESAMIENTO DE IMÁGENES")

    preprocessing_summary = (
        create_preprocessing_summary(
            train_model,
            validation_model,
            test_model,
        )
    )

    print(preprocessing_summary["successfully_processed"])

    print("\nErrores encontrados:")
    print(preprocessing_summary["number_of_errors"])

    print("\nTamaño de salida:")
    print(preprocessing_summary["image_size"])

    print("\nRango esperado:")
    print(preprocessing_summary["expected_range"])


    # RESUMEN FINAL
    print("PROCESAMIENTO FINALIZADO")

    print("Resultados Fase 3:")
    print("results/phase3/")

    print("\nValidaciones principales:")

    print("No fuga por sample_id:", split_validation["no_sample_id_leakage"])
    print("No imágenes idénticas entre particiones:", split_validation["no_exact_image_leakage"])
    print("Imágenes procesadas:", preprocessing_summary["successfully_processed"])
    print("Errores de preprocesamiento:", preprocessing_summary["number_of_errors"])

    from proyecto_asim.generate_phase3_summary import generate_phase3_summary
    from proyecto_asim.plot_phase3 import plot_split_distribution

    generate_phase3_summary()
    plot_split_distribution()

    print("\nPipeline completado correctamente.")


if __name__ == "__main__":
    main()