import os  # Permite interactuar con carpetas y rutas de forma individual.
import shutil  # Permite automatizar tareas repetitivas de gestión de archivos.

import kagglehub


def setup_raw_dataset():

    # Definición de rutas del proyecto.
    dataset = "dankok/diabetic-retinopathy-image-dataset"
    raw_dir = os.path.join("data", "raw")
    os.makedirs(raw_dir, exist_ok=True)

    print("Iniciando descarga del dataset mediante kagglehub...")
    # Descarga usando kagglehub...(función en línea).
    downloaded_path = kagglehub.dataset_download(dataset)
    print(f"Dataset descargado en: {downloaded_path}")

    # Los contenidos deben moverse a data/raw/ para mantener la estructura local.
    print("Organizando archivos en la carpeta del proyecto (data/raw)...")
    for item in os.listdir(downloaded_path):
        # Creación de la ruta de origen exacta del archivo o carpeta temporal.
        s = os.path.join(downloaded_path, item)
        # Creación de la ruta de destino donde debería quedar guardado.
        d = os.path.join(raw_dir, item)
        # ¿El elemento actual es una carpeta?
        if os.path.isdir(s):
            # Si ya existe la ruta destino, la borra por completo.
            if os.path.exists(d):
                shutil.rmtree(d)
            # Copia de la carpeta entera con todo su contenido en la ruta destino.
            shutil.copytree(s, d)
        # Si no es una carpeta, sino un archivo suelto...
        else:
            # Copia del archivo individual a carpeta de destino.
            shutil.copy2(s, d)

    # Generación automática de un archivo README.md con información esencial.
    readme_path = os.path.join(raw_dir, "README.md")
    readme_content = f"""# Documentación del Dataset - Raw Data (Fase 2)

## Información General
* **Nombre del Dataset:** Diabetic Retinopathy Image Dataset
* **Fuente Oficial (Kaggle):** https://www.kaggle.com/datasets/{dataset}
* **Propósito:** Proveer imágenes digitales de fondo de ojo y metadatos para tareas de clasificación de severidad de retinopatía diabética, segmentación de lesiones y localización anatómica.

## Estructura Real de Directorios
* `Disease_Grading/`: 
  * `Groundtruths/`: Contiene los archivos CSV con las etiquetas oficiales de severidad (ej. `IDRiD_Disease Grading_Training Labels.csv`).
  * `Original_Images/`: Contiene los conjuntos de entrenamiento (`Training Set`) y prueba (`Testing Set`) en formato JPG.
* `Localization/`: Datos y coordenadas asociadas a la posición del disco óptico y la fóvea.
* `Segmentation/`: Máscaras a nivel de píxel de lesiones retinianas (microaneurismas, hemorragias, exudados) y disco óptico en formato TIFF.

## Consideraciones Metodológicas y Éticas (CRISP-DM)
1. **Foco del Proyecto (Meta Analítica):** Para la clasificación multiclase de severidad (Fase 1), se utilizará exclusivamente la información y las imágenes contenidas en la carpeta `Disease_Grading`.
2. **Privacidad y Uso:** Datos anonimizados para investigación académica en Machine Learning.
"""

    with open(readme_path, "w", encoding="utf-8") as f:
        f.write(readme_content)

    print(f"Archivo README.md generado en '{readme_path}'.")


if __name__ == "__main__":
    setup_raw_dataset()
